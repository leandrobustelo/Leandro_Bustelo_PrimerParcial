
package sistemabiblioteca;



public class Ilustracion extends Publicacion{
    private String nombreIlustrador;
    private int ancho;
    private int algo;

    public Ilustracion(String nombreIlustrador, int ancho, int algo, String titulo, String anio) {
        super(titulo, anio);
        this.nombreIlustrador = nombreIlustrador;
        this.ancho = ancho;
        this.algo = algo;
    }

    @Override
    public String toString() {
        return "Ilustracion{" + "nombre=" + nombreIlustrador + ", ancho=" + ancho + ", algo=" + algo + '}';
    }
    
    
    
}
