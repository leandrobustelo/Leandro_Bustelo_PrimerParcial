
package sistemabiblioteca;

import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<Publicacion>publicaciones;
    public Biblioteca() {
        publicaciones=new ArrayList<>();
    }
    
    public void agregarPublicacion(Publicacion P){
        boolean aux=false;
        for(int i=0;i<publicaciones.size();i++){
            if(publicaciones.get(i).equals(P)){
                aux=true;
                throw new PublicacionExistenteExeption();
            }
        }
        publicaciones.add(P);
    } 
    public void mostrarPublicaciones(){
        for(Publicacion P:publicaciones){
            System.out.println(P.toString());
        }
    }
    
    public void leerPublicaciones(){
        for(Publicacion P:publicaciones){
            if(P instanceof Libro libro){
                libro.leer();
                System.out.println("");
            }
            else if(P instanceof Revista revista){
                revista.leer();
                System.out.println("");
            }
            else{
                System.out.println("Las ilustraciones no son leibles ");
                System.out.println("");
            }
        }
    }
}
