
package sistemabiblioteca;


public abstract class Publicacion {
    private String titulo;
    private String anio;

    public Publicacion(String titulo, String anio) {
        this.titulo = titulo;
        this.anio = anio;
    }
    
    @Override
    public boolean equals(Object obj) {
       if(this==obj){
           return true;
       }
       if(obj==null || obj.getClass()!=this.getClass()){
         return false;
       }
       Publicacion other=(Publicacion)obj;
        return titulo.equals(other.titulo) && anio.equals(other.anio);  
    }

    @Override
    public String toString() {
        return "Publicacion{" + "titulo=" + titulo + ", anio=" + anio + '}';
    }
    public String getTitulo(){
        return titulo;
    }
}
