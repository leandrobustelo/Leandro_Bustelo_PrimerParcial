
package sistemabiblioteca;


public class SistemaBiblioteca {


    public static void main(String[] args) {
        Biblioteca b1=new Biblioteca();
        
        Publicacion p1=new Libro("pepe",Genero.FICCION,"blancanieves","1987");
        Publicacion p2=new Libro("pepe",Genero.FICCION,"blancanieves","1987");
        Publicacion p3=new Revista(345,"Gano BOCA!!!","2024");
        Publicacion p4=new Revista(345,"Gano BOCA!!!","2024");
        Publicacion p5=new Ilustracion("Quinquela Martin",125,105,"sarasa","1994");
        Publicacion p6=new Ilustracion("Picasso",165,132,"sarasin","1964");
        try{
        b1.agregarPublicacion(p1);
//        b1.agregarPublicacion(p2); TIRA EXEPTION
        b1.agregarPublicacion(p3);
//        b1.agregarPublicacion(p4); TIRA EXEPTION
        b1.agregarPublicacion(p5);
        b1.agregarPublicacion(p6);
        }
        catch(PublicacionExistenteExeption P){
            System.out.println(P.getMessage());
        }
        
        b1.mostrarPublicaciones();
        System.out.println("-------");
        b1.leerPublicaciones();
    }
    
}
