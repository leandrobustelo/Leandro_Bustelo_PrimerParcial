
package sistemabiblioteca;


public class Revista extends Publicacion implements Leible{
    private int numEdicion;

    public Revista(int numEdicion, String titulo, String anio) {
        super(titulo, anio);
        this.numEdicion = numEdicion;
    }

    @Override
    public String toString() {
        return "Revista{" + "numEdicion=" + numEdicion + '}';
    }

    @Override
    public void leer() {
        System.out.println("Leyendo Revista... / Titulo: "+super.getTitulo());
    }
}
