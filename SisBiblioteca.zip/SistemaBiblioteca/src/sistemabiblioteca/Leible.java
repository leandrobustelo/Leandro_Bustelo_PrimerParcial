
package sistemabiblioteca;


public interface Leible{
    void leer();
}
