
package sistemabiblioteca;


public enum Genero {
    FICCION, 
    NO_FICCION, 
    CIENCIA,
    HISTORIA;
}
