
package sistemabiblioteca;


public class PublicacionExistenteExeption extends RuntimeException {
    
    private final static String MESSAGE="La publicacion ya se encuentra en la biblioteca";

    public PublicacionExistenteExeption() {
        super(MESSAGE);
    }
    
    
}
